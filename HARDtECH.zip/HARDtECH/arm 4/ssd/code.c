#include<lpc214x.h>
void delay(int);
int i;
unsigned int a[]={0x3f,0x06,0x5B,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x67};
int main()
{
IO0DIR=IO0DIR|0xffffffff;
	while(1) 
	{
for(i=0;i<=9;i++)
{
IO0SET=IO0SET|a[i];
delay(300);
IO0CLR=IO0CLR|a[i];
}
		
	}
	return 0;
}
void delay(int k)
{
int i,j;
	for(i=0;i<k;i++)
	{
	for(j=0;j<k;j++);
	}
}