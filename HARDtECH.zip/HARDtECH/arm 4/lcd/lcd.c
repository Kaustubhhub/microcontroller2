 #include<lpc214x.h>
 void delay(void);
  void lcd_int(void);
  void lcd_cmd(char command);
  void lcd_string(char *str);
 int main()
 {
 lcd_int();
 lcd_string("hello world");
 delay();
 }
 void delay()
 {
 int i;
 for(i=0;i<1000;i++);
 }
 void lcd_int()
 {
 IO0DIR = 0x0000FFF0;
 delay();
 lcd_cmd(0x38);
  lcd_cmd(0x0f);
   lcd_cmd(0x01);
    lcd_cmd(0x80);
 }
 
 void lcd_cmd(char command)
 {
 IO0PIN = ((IO0PIN &0xFFFF00FF)|(command<<8));
 IO0SET =0x40;
 IO0CLR =0x30;
 delay();
 IO0CLR = 0x40;
 delay();
 }
 void lcd_string(char *str)
 {
 unsigned int i=0;
 while(str[i]!=0)
 {
 IO0PIN = ((IO0PIN &0xFFFF00FF)|(str[i]<<8));
 IO0SET =0x50;
 IO0CLR =0x20;
 delay();
 IO0CLR = 0x40;
 delay();
 i++;
 }
 }