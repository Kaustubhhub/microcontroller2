#include<lpc214x.h>
void delay(unsigned int);
int main(void)
{
LCD_INIT();
	LCD_STRING("HARDIK IS BEST");
	return 0;
}
void delay(unsigned int j)
{
unsigned int x,i;
	for (i=0;i<j;i++)
	{
	for (x=0;x<6000;x++);
	}
}

void LCD_INIT(void)
{
IO0DIR=0x0000fff0;
	delay(20);
	LCD_CMD(0x38);
	LCD_CMD(0x0C);
	LCD_CMD(0x06);
	LCD_CMD(0x01);
	LCD_CMD(0x80);
}
void 	LCD_CMD(char command)
{
IO0PIN=((IO0PIN & 0xFFFF00FF)| (command<<8));
	IO0SET=0x00000040;
	IO0CLR=0x00000030;
	delay(20);
	IO0CLR=0x00000040;
	delay(20);
}
void LCD_STRING(char* msg)
{
unsigned int i=0;
	while (msg[i]!=0)
	{
	IO0PIN=((IO0PIN & 0xFFFF00FF)| (command<<8));
	IO0SET=0x00000050;
	IO0CLR=0x00000020;
	delay(20);
	IO0CLR=0x00000040;
	delay(20);
		i++;
	}
}