#include<lpc214x.h>
void delay(void);
int main(void)
{
IO0DIR=0xF;
	while(1)
	{
		IO0SET=0x0F;
		delay();
		IO0CLR=0x0F;
		delay();
	}
	return 0;
}
void delay(void)
{
int z,c;
	c=0;
	for(z=0;z<400000;z++)
	{
	c++;
	}
}